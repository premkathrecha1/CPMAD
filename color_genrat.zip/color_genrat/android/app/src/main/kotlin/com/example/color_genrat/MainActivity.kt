package com.example.color_genrat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
