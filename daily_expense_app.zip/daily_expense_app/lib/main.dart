import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const DailyExpenseApp());
}

class DailyExpenseApp extends StatelessWidget {
  const DailyExpenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily Expense App',
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(),
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> get _filteredTransactions {
    if (_selectedFilter == "All") return _transactions;
    if (_selectedFilter == "Daily") {
      String today = DateTime.now().toString().split(" ")[0];
      return _transactions.where((t) => t["date"].toString().startsWith(today)).toList();
    }
    if (_selectedFilter == "Weekly") {
      DateTime now = DateTime.now();
      return _transactions.where((t) {
        DateTime? date;
        try {
          date = DateTime.parse(t["date"].toString());
        } catch (_) {
          return false;
        }
        return date.isAfter(now.subtract(const Duration(days: 7)));
      }).toList();
    }
    if (_selectedFilter == "Monthly") {
      DateTime now = DateTime.now();
      return _transactions.where((t) {
        DateTime? date;
        try {
          date = DateTime.parse(t["date"].toString());
        } catch (_) {
          return false;
        }
        return date.month == now.month && date.year == now.year;
      }).toList();
    }
    return _transactions;
  }

  double get filteredTotalIncome {
    return _filteredTransactions
        .where((t) => !t["amount"].toString().contains("-"))
        .map((t) => double.tryParse(t["amount"].toString().replaceAll("$", "")) ?? 0)
        .fold(0, (a, b) => a + b);
  }

  double get filteredTotalSpent {
    return _filteredTransactions
        .where((t) => t["amount"].toString().contains("-"))
        .map((t) => double.tryParse(t["amount"].toString().replaceAll("-$", "")) ?? 0)
        .fold(0, (a, b) => a + b);
  }
  String _selectedFilter = "All";
  final List<Map<String, dynamic>> _transactions = [
    {
      "icon": Icons.fastfood,
      "color": Colors.orange,
      "title": "Food",
      "subtitle": "Card",
      "amount": "-\$12",
      "date": "Mar 07, 2023",
    },
    {
      "icon": Icons.attach_money,
      "color": Colors.green,
      "title": "Salary",
      "subtitle": "Bank Account",
      "amount": "\$6800",
      "date": "Mar 07, 2023",
    },
  ];

  double get totalIncome {
    return _transactions
        .where((t) => !t["amount"].toString().contains("-"))
        .map((t) => double.tryParse(t["amount"].toString().replaceAll("\$", "")) ?? 0)
        .fold(0, (a, b) => a + b);
  }

  double get totalSpent {
    return _transactions
        .where((t) => t["amount"].toString().contains("-"))
        .map((t) => double.tryParse(t["amount"].toString().replaceAll("-\$", "")) ?? 0)
        .fold(0, (a, b) => a + b);
  }

  Future<void> _openAddTransaction() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AddTransactionPage()),
    );

    if (result != null && result is Map<String, dynamic>) {
      setState(() {
        _transactions.add({
          "icon": Icons.category,
          "color": Colors.blue,
          "title": result["category"],
          "subtitle": result["payment"],
          "amount": result["isDraft"]
              ? "-\$0 (Draft)"
              : (result["amount"] > 0 ? "\$${result["amount"]}" : "-\$${result["amount"].abs()}"),
          "date": DateTime.now().toString().split(" ")[0],
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        shape: const CircleBorder(),
        onPressed: _openAddTransaction,
        child: const Icon(Icons.add, size: 32, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8.0,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              IconButton(icon: const Icon(Icons.home), onPressed: () {}),
              IconButton(icon: const Icon(Icons.swap_horiz), onPressed: () {}),
              const SizedBox(width: 40), // space for FAB
              IconButton(icon: const Icon(Icons.account_balance_wallet), onPressed: () {}),
              IconButton(icon: const Icon(Icons.person), onPressed: () {}),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView( // ✅ Fix overflow
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Hello,\nDavid",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const CircleAvatar(
                      radius: 22,
                      backgroundColor: Colors.grey,
                      child: Icon(Icons.notifications_none, color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Filter Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _filterButton("All", _selectedFilter == "All", () => setState(() => _selectedFilter = "All")),
                    _filterButton("Daily", _selectedFilter == "Daily", () => setState(() => _selectedFilter = "Daily")),
                    _filterButton("Weekly", _selectedFilter == "Weekly", () => setState(() => _selectedFilter = "Weekly")),
                    _filterButton("Monthly", _selectedFilter == "Monthly", () => setState(() => _selectedFilter = "Monthly")),
                  ],
                ),
                const SizedBox(height: 20),

                // Income & Spent Chart
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 150,
                        child: PieChart(
                          PieChartData(
                            sections: [
                              PieChartSectionData(
                                value: filteredTotalIncome,
                                color: Colors.green,
                                radius: 40,
                                title: "",
                              ),
                              PieChartSectionData(
                                value: filteredTotalSpent,
                                color: Colors.redAccent,
                                radius: 40,
                                title: "",
                              ),
                            ],
                            sectionsSpace: 2,
                            centerSpaceRadius: 40,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _statBox(color: Colors.green, title: "Income", amount: "\$${filteredTotalIncome.toStringAsFixed(0)}"),
                          _statBox(color: Colors.redAccent, title: "Spent", amount: "\$${filteredTotalSpent.toStringAsFixed(0)}"),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Recent Transactions
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Recent transactions",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    Text("See All", style: TextStyle(color: Colors.grey)),
                  ],
                ),
                const SizedBox(height: 15),

                Column(
                  children: _filteredTransactions
                      .map((t) => _transactionTile(
                            icon: t["icon"],
                            color: t["color"],
                            title: t["title"],
                            subtitle: t["subtitle"],
                            amount: t["amount"],
                            date: t["date"],
                          ))
                      .toList(),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ------------------ Widgets ------------------

class _transactionTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final String amount;
  final String date;

  const _transactionTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: color.withOpacity(0.2),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                Text(subtitle, style: const TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(amount, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              Text(date, style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          )
        ],
      ),
    );
  }
}

class _statBox extends StatelessWidget {
  final Color color;
  final String title;
  final String amount;

  const _statBox({required this.color, required this.title, required this.amount});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(color: Colors.grey)),
            Text(amount, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }
}

Widget _filterButton(String text, bool isSelected, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
      decoration: BoxDecoration(
        color: isSelected ? Colors.green.shade100 : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isSelected ? Colors.green : Colors.black,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
  );
}

// ------------------ Add Transaction Page ------------------

class AddTransactionPage extends StatefulWidget {
  const AddTransactionPage({super.key});

  @override
  State<AddTransactionPage> createState() => _AddTransactionPageState();
}

class _AddTransactionPageState extends State<AddTransactionPage> {
  final TextEditingController _amountController = TextEditingController();
  String _selectedCategory = "Food";
  String _selectedPayment = "Cash";

  final List<String> _categories = ["Food", "Travel", "Shopping", "Bills"];
  final List<String> _paymentTypes = ["Cash", "Card", "UPI"];

  void _saveTransaction(bool isDraft) {
    if (_amountController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter an amount")),
      );
      return;
    }

    final transaction = {
      "amount": double.parse(_amountController.text),
      "category": _selectedCategory,
      "payment": _selectedPayment,
      "isDraft": isDraft,
    };

    Navigator.pop(context, transaction);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Transaction"),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Amount Input
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: "Amount",
                prefixText: "\$ ",
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),

            // Category Dropdown
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              items: _categories
                  .map((cat) => DropdownMenuItem(
                        value: cat,
                        child: Text(cat),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCategory = value!;
                });
              },
              decoration: const InputDecoration(
                labelText: "Category",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),

            // Payment Type Dropdown
            DropdownButtonFormField<String>(
              value: _selectedPayment,
              items: _paymentTypes
                  .map((pay) => DropdownMenuItem(
                        value: pay,
                        child: Text(pay),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedPayment = value!;
                });
              },
              decoration: const InputDecoration(
                labelText: "Payment Type",
                border: OutlineInputBorder(),
              ),
            ),
            const Spacer(),

            // Buttons Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 12),
                  ),
                  onPressed: () => _saveTransaction(true),
                  child: const Text("Draft"),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 12),
                  ),
                  onPressed: () => _saveTransaction(false),
                  child: const Text("Add"),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
