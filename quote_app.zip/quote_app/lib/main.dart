import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const QuoteApp());
}

class QuoteApp extends StatelessWidget {
  const QuoteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: QuoteHome(),
    );
  }
}

class QuoteHome extends StatefulWidget {
  @override
  State<QuoteHome> createState() => _QuoteHomeState();
}

class _QuoteHomeState extends State<QuoteHome> {
  String quote = "";
  String author = "";
  List<Map<String, String>> history = [];

  @override
  void initState() {
    super.initState();
    fetchQuote();
  }

  // Fetch Quote From API
  Future<void> fetchQuote() async {
    final url = Uri.parse("https://zenquotes.io/api/random/");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body)[0];

      setState(() {
        quote = json["q"];
        author = json["a"];

        history.add({
          "quote": quote,
          "author": author,
        });
      });
    } else {
      setState(() {
        quote = "Failed to load quote!";
        author = "";
      });
    }
  }

  // Navigate to History Page
  void openHistory() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuoteHistoryScreen(history: history),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Random Quote App"),
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            onPressed: openHistory,
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                quote,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 24,
                  fontStyle: FontStyle.italic,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                "- $author",
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: fetchQuote,
                child: const Text("Refresh Quote"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class QuoteHistoryScreen extends StatelessWidget {
  final List<Map<String, String>> history;

  const QuoteHistoryScreen({super.key, required this.history});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Quote History")),
      body: ListView.builder(
        itemCount: history.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              title: Text(
                history[index]["quote"]!,
                style: const TextStyle(fontSize: 18),
              ),
              subtitle: Text("- ${history[index]["author"]}"),
            ),
          );
        },
      ),
    );
  }
}
