import 'package:flutter/material.dart';

void main() {
  runApp(const GstCalculatorApp());
}

/// Main App Widget
class GstCalculatorApp extends StatelessWidget {
  const GstCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'GST Calculator',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const GstCalculatorScreen(),
    );
  }
}

/// GST Calculator Screen
class GstCalculatorScreen extends StatefulWidget {
  const GstCalculatorScreen({super.key});

  @override
  State<GstCalculatorScreen> createState() => _GstCalculatorScreenState();
}

class _GstCalculatorScreenState extends State<GstCalculatorScreen> {
  // Controllers for input fields
  final TextEditingController actualAmountController = TextEditingController();
  final TextEditingController totalAmountController = TextEditingController();

  // Roll number → Example: Replace with your roll no.
  final int rollNo = 7;

  // GST percentage = (roll_no * 10) % 100
  late final double gstPercent;

  // Outputs
  double igst = 0;
  double cgst = 0;
  double sgst = 0;
  double totalAmount = 0;
  double actualAmount = 0;

  // Track case (Case 1 or Case 2)
  bool isCase1 = true;

  @override
  void initState() {
    super.initState();
    gstPercent = (rollNo * 10) % 100;
  }

  /// Function to calculate GST for Case 1
  void calculateFromActualAmount() {
    if (actualAmountController.text.isEmpty) return;

    actualAmount = double.parse(actualAmountController.text);

    // GST is split equally between CGST & SGST
    igst = (actualAmount * gstPercent) / 100;
    cgst = igst / 2;
    sgst = igst / 2;
    totalAmount = actualAmount + igst;

    setState(() {});
  }

  /// Function to calculate GST for Case 2
  void calculateFromTotalAmount() {
    if (totalAmountController.text.isEmpty) return;

    totalAmount = double.parse(totalAmountController.text);

    // Formula: Actual = Total / (1 + GST%)
    actualAmount = totalAmount / (1 + gstPercent / 100);
    igst = totalAmount - actualAmount;
    cgst = igst / 2;
    sgst = igst / 2;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("GST Calculator")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Toggle between Case 1 and Case 2
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ChoiceChip(
                  label: const Text("Case 1"),
                  selected: isCase1,
                  onSelected: (val) {
                    setState(() => isCase1 = true);
                  },
                ),
                const SizedBox(width: 10),
                ChoiceChip(
                  label: const Text("Case 2"),
                  selected: !isCase1,
                  onSelected: (val) {
                    setState(() => isCase1 = false);
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Input Field for Case 1
            if (isCase1)
              TextField(
                controller: actualAmountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Enter Actual Amount",
                ),
              ),

            // Input Field for Case 2
            if (!isCase1)
              TextField(
                controller: totalAmountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Enter Total Amount",
                ),
              ),

            const SizedBox(height: 20),

            // Calculate Button
            ElevatedButton(
              onPressed: () {
                if (isCase1) {
                  calculateFromActualAmount();
                } else {
                  calculateFromTotalAmount();
                }
              },
              child: const Text("Calculate"),
            ),

            const SizedBox(height: 30),

            // Output Section
            if (igst != 0 || totalAmount != 0)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("GST %: $gstPercent"),
                  Text("Actual Amount: ${actualAmount.toStringAsFixed(2)}"),
                  Text("IGST: ${igst.toStringAsFixed(2)}"),
                  Text("CGST: ${cgst.toStringAsFixed(2)}"),
                  Text("SGST: ${sgst.toStringAsFixed(2)}"),
                  Text("Total Amount: ${totalAmount.toStringAsFixed(2)}"),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
