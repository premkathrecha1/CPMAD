import 'package:flutter/material.dart';

void main() {
  runApp(ContactDiaryApp());
}

/// Root widget of the app
class ContactDiaryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Contact Diary',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ContactDiary(),
    );
  }
}

/// Stateful widget to manage adding and displaying contacts
class ContactDiary extends StatefulWidget {
  @override
  _ContactDiaryState createState() => _ContactDiaryState();
}

class _ContactDiaryState extends State<ContactDiary> {
  // Controllers for text input
  final TextEditingController nameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  // List to store contacts
  List<Map<String, String>> contacts = [];

  /// Function to add a new contact
  void addContact() {
    if (nameController.text.isNotEmpty &&
        mobileController.text.isNotEmpty &&
        emailController.text.isNotEmpty) {
      setState(() {
        contacts.add({
          "name": nameController.text,
          "mobile": mobileController.text,
          "email": emailController.text,
        });
      });

      // Clear fields after adding
      nameController.clear();
      mobileController.clear();
      emailController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Contact Diary"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Input Fields
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 8),
                TextField(
                  controller: mobileController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: "Mobile Number",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 8),
                TextField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: "Email",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: addContact,
                  child: Text("Add Contact"),
                ),
              ],
            ),
          ),

          // Display Contacts
          Expanded(
            child: ListView.builder(
              itemCount: contacts.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(contacts[index]["name"]!),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(" ${contacts[index]["mobile"]}"),
                        Text(" ${contacts[index]["email"]}"),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
