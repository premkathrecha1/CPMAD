import 'package:flutter/material.dart';
import '../models/customer.dart';
import '../models/item.dart';

class RadioTestScreen extends StatefulWidget {
  const RadioTestScreen({super.key});

  @override
  State<RadioTestScreen> createState() => _RadioTestScreenState();
}

class _RadioTestScreenState extends State<RadioTestScreen> {
  // Controllers for customer
  final TextEditingController nameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();

  // Controllers for product
  final TextEditingController productController = TextEditingController();
  final TextEditingController qtyController = TextEditingController();
  final TextEditingController priceController = TextEditingController();

  Customer? customer;

  void addCustomerAndItem() {
    if (nameController.text.isEmpty ||
        mobileController.text.isEmpty ||
        productController.text.isEmpty ||
        qtyController.text.isEmpty ||
        priceController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    // Create item
    Item item = Item(
      productName: productController.text,
      quantity: int.tryParse(qtyController.text) ?? 0,
      price: double.tryParse(priceController.text) ?? 0,
      prodName: '',
      qty: 0,
      rate: 0.0,
      gstPer: 0.0,
    );

    // If customer not created yet, create new
    if (customer == null) {
      customer = Customer(
        name: nameController.text,
        mono: mobileController.text,
        items: [item],
      );
    } else {
      customer!.items.add(item);
    }

    setState(() {});

    // Clear product fields (keep customer fields)
    productController.clear();
    qtyController.clear();
    priceController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Customer & Product Form"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Customer Details",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: "Customer Name"),
            ),
            TextField(
              controller: mobileController,
              decoration: const InputDecoration(labelText: "Mobile Number"),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 20),

            const Text("Product Details",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextField(
              controller: productController,
              decoration: const InputDecoration(labelText: "Product Name"),
            ),
            TextField(
              controller: qtyController,
              decoration: const InputDecoration(labelText: "Quantity"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: priceController,
              decoration: const InputDecoration(labelText: "Price"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),

            Center(
              child: ElevatedButton(
                onPressed: addCustomerAndItem,
                child: const Text("Add Product"),
              ),
            ),
            const SizedBox(height: 20),

            if (customer != null) ...[
              Text(customer!.getDetails(),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                itemCount: customer!.items.length,
                itemBuilder: (context, index) {
                  final item = customer!.items[index];
                  return ListTile(
                    leading: const Icon(Icons.shopping_cart),
                    title: Text(item.productName),
                    subtitle: Text(
                        "Qty: ${item.quantity}, Price: ₹${item.price}, Total: ₹${item.getTotalCost()}"),
                  );
                },
              ),
              const SizedBox(height: 10),
              Text("Total Bill: ₹${customer!.getTotalBill()}",
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ],
        ),
      ),
    );
  }
}

extension on Item {
  getTotalCost() {}
}
