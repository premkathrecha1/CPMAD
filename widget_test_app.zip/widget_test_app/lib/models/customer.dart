import 'item.dart';

class Customer {
  String name;
  String mono;
  List<Item> items; // products the customer buys

  Customer({
    required this.name,
    required this.mono,
    required this.items,
  });

  // Method: calculate total amount
  double getTotalBill() {
    double total = 0;
    for (var item in items) {
      total += item.price * item.quantity;
    }
    return total;
  }

  // Method: get customer details as string
  String getDetails() {
    return "Customer: $name, Mobile: $mono";
  }
}
