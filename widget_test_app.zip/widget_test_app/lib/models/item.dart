class Item {
  String productName;
  int quantity;
  double price;

  Item({
    required this.productName,
    required this.quantity,
    required this.price, required String prodName, required double qty, required double rate, required double gstPer,
  });

  Null get qty => null;

  double getTotalPrice() {
    return quantity * price;
  }
}
