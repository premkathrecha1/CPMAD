import 'package:flutter/material.dart';
import 'package:sensor_plus/sensor_plus.dart';
import 'dart:async';

void main() {
  runApp(const SensorApp());
}

class SensorApp extends StatelessWidget {
  const SensorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SensorHome(),
    );
  }
}

class SensorHome extends StatefulWidget {
  @override
  State<SensorHome> createState() => _SensorHomeState();
}

class _SensorHomeState extends State<SensorHome> {
  AccelerometerEvent? accel;
  GyroscopeEvent? gyro;

  List<double> accelX = [];
  List<double> accelY = [];
  List<double> accelZ = [];

  bool shakeDetected = false;

  @override
  void initState() {
    super.initState();

    // Accelerometer listener
    accelerometerEvents.listen((event) {
      setState(() {
        accel = event;
        accelX.add(event.x);
        accelY.add(event.y);
        accelZ.add(event.z);

        analyzeShake(event);
      });
    });

    // Gyroscope listener
    gyroscopeEvents.listen((event) {
      setState(() {
        gyro = event;
      });
    });
  }

  // Shake detection logic
  void analyzeShake(AccelerometerEvent event) {
    double magnitude =
        (event.x.abs() + event.y.abs() + event.z.abs()).toDouble();

    if (magnitude > 30) {
      shakeDetected = true;
    } else {
      shakeDetected = false;
    }
  }

  // Calculate average of a list
  double calcAverage(List<double> values) {
    if (values.isEmpty) return 0;
    return values.reduce((a, b) => a + b) / values.length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sensor Data Analysis"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("📌 Live Accelerometer Data",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              Text("X: ${accel?.x.toStringAsFixed(3) ?? '0'}"),
              Text("Y: ${accel?.y.toStringAsFixed(3) ?? '0'}"),
              Text("Z: ${accel?.z.toStringAsFixed(3) ?? '0'}"),

              const SizedBox(height: 25),

              const Text("📌 Live Gyroscope Data",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              Text("X: ${gyro?.x.toStringAsFixed(3) ?? '0'}"),
              Text("Y: ${gyro?.y.toStringAsFixed(3) ?? '0'}"),
              Text("Z: ${gyro?.z.toStringAsFixed(3) ?? '0'}"),

              const SizedBox(height: 25),

              const Text("📊 Accelerometer Averages",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              Text("Avg X: ${calcAverage(accelX).toStringAsFixed(3)}"),
              Text("Avg Y: ${calcAverage(accelY).toStringAsFixed(3)}"),
              Text("Avg Z: ${calcAverage(accelZ).toStringAsFixed(3)}"),

              const SizedBox(height: 25),

              const Text("⚠ Shake Detection",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: shakeDetected ? Colors.red : Colors.green,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  shakeDetected ? "SHAKE DETECTED!" : "Normal",
                  style: const TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
