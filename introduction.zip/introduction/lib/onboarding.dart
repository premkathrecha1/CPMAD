import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'home.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  Future<void> _onDone(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('seenOnboarding', true);

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return IntroductionScreen(
      pages: [
        PageViewModel(
          title: "Welcome ",
          body: "This app helps you manage tasks efficiently.",
          image: const Center(child: Icon(Icons.task, size: 120)),
          decoration: const PageDecoration(pageColor: Colors.white),
        ),
        PageViewModel(
          title: "Stay Organized ",
          body: "Organize your daily work with ease.",
          image: const Center(child: Icon(Icons.calendar_today, size: 120)),
          decoration: const PageDecoration(pageColor: Colors.white),
        ),
        PageViewModel(
          title: "Get Started ",
          body: "Let’s begin your journey!",
          image: const Center(child: Icon(Icons.thumb_up, size: 120)),
          decoration: const PageDecoration(pageColor: Colors.white),
        ),
      ],
      showSkipButton: true,
      skip: const Text("Skip"),
      next: const Text("Next"),
      done: const Text("Done", style: TextStyle(fontWeight: FontWeight.w600)),
      onDone: () => _onDone(context),
      onSkip: () => _onDone(context),
      dotsDecorator: const DotsDecorator(
        size: Size.square(10.0),
        activeSize: Size(20.0, 10.0),
        activeShape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(25.0)),
        ),
      ),
    );
  }
}
