import 'package:flutter/material.dart';
import 'package:flutter_application_1/cart_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: CartPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool isHidden = true;
  String msg = '';
  Color msgColor = Colors.black;

  TextEditingController userTxtCtl = TextEditingController();
  TextEditingController pwdTxtCtl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Login',
              style: TextStyle(fontSize: 50, color: Colors.deepPurple),
            ),
            SizedBox(height: 30),
            TextField(
              controller: userTxtCtl,
              decoration: InputDecoration(
                labelText: 'Username',
                hintText: 'Enter your name',
                prefixIcon: Icon(Icons.person),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: pwdTxtCtl,
              obscureText: isHidden,
              decoration: InputDecoration(
                labelText: 'Password',
                hintText: 'Enter password',
                prefixIcon: Icon(Icons.key),
                suffixIcon: IconButton(
                  onPressed: () {
                    isHidden = !isHidden;
                    setState(() {});
                  },
                  icon: Icon(
                      isHidden ? Icons.visibility_off : Icons.visibility),
                ),
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                if (userTxtCtl.text.isNotEmpty &&
                    pwdTxtCtl.text.isNotEmpty) {
                  if (userTxtCtl.text == pwdTxtCtl.text) {
                    msg = 'Welcome ${userTxtCtl.text}';
                    msgColor = Colors.green;
                  } else {
                    msg = 'Invalid credentials';
                    msgColor = Colors.red;
                  }
                } else {
                  msg = 'Please enter credentials';
                  msgColor = Colors.red;
                }
                setState(() {});
              },
              child: Text('Login'),
            ),
            SizedBox(height: 20),
            Text(
              msg,
              style: TextStyle(
                color: msgColor,
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
