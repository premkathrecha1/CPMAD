// lib/models/todo.dart
class Todo {
  final int? id;          // null when creating a new todo
  final String title;
  final bool isCompleted;

  const Todo({
    this.id,
    required this.title,
    required this.isCompleted,
  });

  // JSON → Todo
  factory Todo.fromJson(Map<String, dynamic> json) {
    return Todo(
      id: json['id'] as int?,
      title: json['title'] as String,
      isCompleted: (json['completed'] as bool?) ?? false,
    );
  }

  // Todo → JSON (only the fields the API accepts)
  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'completed': isCompleted,
    };
  }

  // Helper for immutable updates
  Todo copyWith({int? id, String? title, bool? isCompleted}) {
    return Todo(
      id: id ?? this.id,
      title: title ?? this.title,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}