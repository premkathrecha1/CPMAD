import 'package:flutter/material.dart';

void main() {
  runApp(const UnitConverterApp());
}

/// Main App
class UnitConverterApp extends StatelessWidget {
  const UnitConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Unit Converter",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const UnitConverterHome(),
    );
  }
}

/// Home Screen
class UnitConverterHome extends StatefulWidget {
  const UnitConverterHome({super.key});

  @override
  State<UnitConverterHome> createState() => _UnitConverterHomeState();
}

class _UnitConverterHomeState extends State<UnitConverterHome> {
  // Controller for user input
  final TextEditingController inputController = TextEditingController();

  // Dropdown selections
  String category = "Length";
  String conversion = "Meter → Kilometer";

  // Output result
  String result = "";

  /// Conversion Logic
  void convert() {
    if (inputController.text.isEmpty) return;

    double input = double.parse(inputController.text);
    double output = 0;

    if (category == "Length") {
      if (conversion == "Meter → Kilometer") {
        output = input / 1000;
      } else {
        output = input * 1000;
      }
    } else if (category == "Weight") {
      if (conversion == "Gram → Kilogram") {
        output = input / 1000;
      } else {
        output = input * 1000;
      }
    } else if (category == "Temperature") {
      if (conversion == "Celsius → Fahrenheit") {
        output = (input * 9 / 5) + 32;
      } else {
        output = (input - 32) * 5 / 9;
      }
    } else if (category == "Area") {
      if (conversion == "Sq. Meter → Sq. Kilometer") {
        output = input / 1000000;
      } else {
        output = input * 1000000;
      }
    }

    setState(() {
      result = "Result: $output";
    });
  }

  @override
  Widget build(BuildContext context) {
    // Conversion options
    Map<String, List<String>> options = {
      "Length": ["Meter → Kilometer", "Kilometer → Meter"],
      "Weight": ["Gram → Kilogram", "Kilogram → Gram"],
      "Temperature": ["Celsius → Fahrenheit", "Fahrenheit → Celsius"],
      "Area": ["Sq. Meter → Sq. Kilometer", "Sq. Kilometer → Sq. Meter"],
    };

    return Scaffold(
      appBar: AppBar(title: const Text("Unit Converter")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Select Category
            DropdownButton<String>(
              value: category,
              items: options.keys
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (val) {
                setState(() {
                  category = val!;
                  conversion = options[category]![0];
                });
              },
            ),

            // Select Conversion
            DropdownButton<String>(
              value: conversion,
              items: options[category]!
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (val) {
                setState(() => conversion = val!);
              },
            ),

            // Input Field
            TextField(
              controller: inputController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Enter value",
              ),
            ),

            const SizedBox(height: 20),

            // Convert Button
            ElevatedButton(
              onPressed: convert,
              child: const Text("Convert"),
            ),

            const SizedBox(height: 20),

            // Show Result
            Text(
              result,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
