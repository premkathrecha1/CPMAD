class Quiz {
  int id;
  String 
}