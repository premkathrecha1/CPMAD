import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:user_app/controllers/app_controller.dart';

class ColorScreen extends StatelessWidget {
  double opacity = 1;
  @override
  Widget build(BuildContext context) {
    var controller = Provider.of<AppController>(context);
    return Container(
      color: Color.fromRGBO(controller.r, controller.g, controller.b, opacity),
      child: Center(
        child: Column(
          children: [
            Slider(
              value: (controller.r / 255).toDouble(),
              onChanged: (val) {
                // r = (val * 255).toInt();
                controller.updateR(val);
                //  print(r);
              },
            ),
            Slider(
              value: (controller.g / 255).toDouble(),
              onChanged: (val) {
                // r = (val * 255).toInt();
                controller.updateG(val);
                //  print(r);
              },
            ),
            Slider(
              value: (controller.b / 255).toDouble(),
              onChanged: (val) {
                // r = (val * 255).toInt();
                controller.updateB(val);
                //  print(r);
              },
            ),
            Text('Color Screen', style: TextStyle(color: Colors.amber)),
          ],
        ),
      ),
    );
  }
}