import 'package:flutter/material.dart';

class PersonScreen extends StatelessWidget {
  const PersonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
      ),
      itemCount: 10,
      itemBuilder: (context, index) {
        return Hero(
          tag: "Image $index",
          child: GestureDetector(
            child: Card(
              child: Image.network("https://picsum.photos/seed/$index/800"),
            ),
            onTap: () {},
          ),
        );
      },
    );
  }
}
