import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../l10n/app_localizations.dart';

class LocaleService with ChangeNotifier {
  Locale _locale = Locale('en');

  Locale get locale => _locale;

  LocaleService() {
    _loadLocale();
  }
  void _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    _locale = Locale(prefs.getString('langCode') ?? 'en');
    notifyListeners();
  }

  void changeLanguage(String langCode) async {
    _locale = Locale(langCode);
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('langCode', langCode);
  }

  static const localizationsDelegates = [
    AppLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];
  static Locale? localResolutionCallback(devicesLocale, supportedLocales) {
    for (var locale in supportedLocales) {
      if (locale.languageCode == devicesLocale.languageCode) {
        return devicesLocale;
      }
    }
    return supportedLocales.First;
  }
}
