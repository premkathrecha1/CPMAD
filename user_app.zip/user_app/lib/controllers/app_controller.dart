import 'package:flutter/widgets.dart';

class AppController with ChangeNotifier {
  int r = 100;
  int g = 100;
  int b = 100;
  void updateR(double rval) {
    r = (rval * 255).toInt();
    notifyListeners();
  }

  void updateG(double gval) {
    g = (gval * 255).toInt();
    notifyListeners();
  }

  void updateB(double bval) {
    b = (bval * 255).toInt();
    notifyListeners();
  }
}
