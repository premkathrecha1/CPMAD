package com.example.user_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
