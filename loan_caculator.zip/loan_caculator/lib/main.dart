// Updated Flutter app for Loan Calculator (EMI).
// Changes: Removed default values for principal (1000) and interest (10%) controllers.
// Now fields are empty by default, so users can input their own values.
// Other features remain the same: Supports simple and compound interest.
// Setup instructions same as before.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math' as math; // For pow function

void main() {
  runApp(const LoanCalculatorApp());
}

class LoanCalculatorApp extends StatelessWidget {
  const LoanCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Loan Calculator',
      theme: ThemeData(
        primaryColor: Colors.orange,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
          ),
        ),
      ),
      home: const InputScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InputScreen extends StatefulWidget {
  const InputScreen({super.key});

  @override
  State<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _principalController = TextEditingController(); // No default
  final TextEditingController _interestController = TextEditingController(); // No default
  int _years = 10;
  int _months = 0;
  String _interestType = 'Compound'; // Default to Compound as in screenshot

  void _showTenurePicker() {
    showDialog(
      context: context,
      builder: (context) {
        int tempYears = _years;
        int tempMonths = _months;
        return AlertDialog(
          title: const Text('Select Loan Tenure'),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Years'),
                  SizedBox(
                    height: 100,
                    width: 80,
                    child: ListWheelScrollView.useDelegate(
                      itemExtent: 40,
                      onSelectedItemChanged: (index) => tempYears = index,
                      childDelegate: ListWheelChildLoopingListDelegate(
                        children: List.generate(31, (index) => Center(child: Text('$index'))),
                      ),
                      useMagnifier: true,
                      magnification: 1.2,
                    ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Months'),
                  SizedBox(
                    height: 100,
                    width: 80,
                    child: ListWheelScrollView.useDelegate(
                      itemExtent: 40,
                      onSelectedItemChanged: (index) => tempMonths = index,
                      childDelegate: ListWheelChildLoopingListDelegate(
                        children: List.generate(12, (index) => Center(child: Text('$index'))),
                      ),
                      useMagnifier: true,
                      magnification: 1.2,
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _years = tempYears;
                  _months = tempMonths;
                });
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _calculate() {
    if (_formKey.currentState!.validate()) {
      double principal = double.parse(_principalController.text);
      double rate = double.parse(_interestController.text);
      int totalMonths = _years * 12 + _months;

      if (totalMonths == 0) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tenure must be at least 1 month')));
        return;
      }

      double emi = 0;
      double totalPayment = 0;
      double totalInterest = 0;

      if (_interestType == 'Compound') {
        double monthlyRate = rate / 12 / 100;
        emi = principal * monthlyRate * math.pow(1 + monthlyRate, totalMonths) / (math.pow(1 + monthlyRate, totalMonths) - 1);
        totalPayment = emi * totalMonths;
        totalInterest = totalPayment - principal;
      } else { // Simple
        totalInterest = principal * rate * (_years + _months / 12) / 100;
        totalPayment = principal + totalInterest;
        emi = totalPayment / totalMonths;
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultScreen(
            emi: emi,
            totalPayment: totalPayment,
            principal: principal,
            totalInterest: totalInterest,
            years: _years,
            months: _months,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Loan calculator'),
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () {}), // Placeholder
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Principal', style: TextStyle(fontSize: 16)),
              TextFormField(
                controller: _principalController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                decoration: const InputDecoration(border: InputBorder.none),
                style: const TextStyle(fontSize: 32),
                validator: (value) => value!.isEmpty || double.tryParse(value) == null || double.parse(value) <= 0 ? 'Enter valid principal' : null,
              ),
              const SizedBox(height: 16),
              const Text('Interest (percentage)', style: TextStyle(fontSize: 16)),
              TextFormField(
                controller: _interestController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                decoration: const InputDecoration(border: InputBorder.none),
                style: const TextStyle(fontSize: 32),
                validator: (value) => value!.isEmpty || double.tryParse(value) == null || double.parse(value) <= 0 ? 'Enter valid interest' : null,
              ),
              const SizedBox(height: 16),
              const Text('Loan tenure', style: TextStyle(fontSize: 16)),
              GestureDetector(
                onTap: _showTenurePicker,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('$_years years $_months month', style: const TextStyle(fontSize: 16)),
                      const Icon(Icons.arrow_forward_ios, size: 16),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text('Interest Type', style: TextStyle(fontSize: 16)),
              DropdownButton<String>(
                value: _interestType,
                isExpanded: true,
                items: const [
                  DropdownMenuItem(value: 'Compound', child: Text('Compound')),
                  DropdownMenuItem(value: 'Simple', child: Text('Simple')),
                ],
                onChanged: (value) => setState(() => _interestType = value!),
              ),
              const Spacer(),
              Center(
                child: ElevatedButton(
                  onPressed: _calculate,
                  child: const Text('Calculate'),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _principalController.dispose();
    _interestController.dispose();
    super.dispose();
  }
}

class ResultScreen extends StatelessWidget {
  final double emi;
  final double totalPayment;
  final double principal;
  final double totalInterest;
  final int years;
  final int months;

  const ResultScreen({
    super.key,
    required this.emi,
    required this.totalPayment,
    required this.principal,
    required this.totalInterest,
    required this.years,
    required this.months,
  });

  String _formatNumber(double number) {
    return number.toStringAsFixed(2).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},');
  }

  @override
  Widget build(BuildContext context) {
    double total = principal + totalInterest;
    double principalRatio = total > 0 ? principal / total : 0;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Results'),
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text('EMI', style: TextStyle(fontSize: 18)),
                    Text('$years years $months month', style: const TextStyle(color: Colors.grey)),
                    Text('₹ ${_formatNumber(emi)}', style: const TextStyle(fontSize: 32, color: Colors.orange, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text('Total payment', style: TextStyle(color: Colors.grey)),
                    Text(_formatNumber(totalPayment), style: const TextStyle(fontSize: 24)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          flex: (principalRatio * 100).toInt(),
                          child: Container(height: 4, color: Colors.teal),
                        ),
                        Expanded(
                          flex: ((1 - principalRatio) * 100).toInt(),
                          child: Container(height: 4, color: Colors.orange),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.circle, size: 8, color: Colors.teal),
                            const SizedBox(width: 4),
                            const Text('Total principal', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                        Row(
                          children: [
                            const Icon(Icons.circle, size: 8, color: Colors.orange),
                            const SizedBox(width: 4),
                            const Text('Total interest', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(_formatNumber(principal)),
                        Text(_formatNumber(totalInterest)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text('Powered by Mi Calculator', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {}, // Placeholder for Stats
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black),
                  child: const Text('Stats'),
                ),
                ElevatedButton(
                  onPressed: () {}, // Placeholder for Share
                  child: const Text('Share'),
                ),
              ],
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}