package com.example.loan_caculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
