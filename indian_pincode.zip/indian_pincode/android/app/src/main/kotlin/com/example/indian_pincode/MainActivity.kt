package com.example.indian_pincode

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
