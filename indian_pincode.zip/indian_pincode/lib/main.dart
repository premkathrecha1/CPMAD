import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const PincodeFinderApp());
}

class PincodeFinderApp extends StatelessWidget {
  const PincodeFinderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Indian Pincode Finder',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const PincodeFinderPage(),
    );         
  }
}

class PincodeFinderPage extends StatefulWidget {
  const PincodeFinderPage({super.key});

  @override
  State<PincodeFinderPage> createState() => _PincodeFinderPageState();
}

class _PincodeFinderPageState extends State<PincodeFinderPage> {
  final TextEditingController _controller = TextEditingController();
  String city = '', district = '', state = '', message = '';
  List<String> postOffices = [];
  bool loading = false;

  Future<void> fetchPincodeData() async {
    final pincode = _controller.text.trim();
    if (pincode.length != 6) {
      setState(() => message = " Please enter a valid 6-digit pincode");
      return;
    }

    setState(() {
      loading = true;
      message = '';
      city = district = state = '';
      postOffices = [];
    });

    try {
      final response = await http.get(
        Uri.parse('https://api.postalpincode.in/pincode/$pincode'),
      );
      final data = json.decode(response.body);

      if (data[0]['Status'] == 'Success') {
        final postOfficeList = data[0]['PostOffice'] as List;
        final first = postOfficeList[0];

        setState(() {
          city = first['Division'] ?? '';
          district = first['District'] ?? '';
          state = first['State'] ?? '';
          postOffices = postOfficeList.map((po) => po['Name'].toString()).toList();
        });
      } else {
        setState(() => message = " Invalid Pincode or not found.");
      }
    } catch (e) {
      setState(() => message = " Error fetching data. Check connection.");
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Indian Pincode Finder")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              maxLength: 6,
              decoration: const InputDecoration(
                labelText: "Enter 6-digit Pincode",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_on),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: loading ? null : fetchPincodeData,
              icon: const Icon(Icons.search),
              label: const Text("Search"),
            ),
            const SizedBox(height: 20),
            if (loading) const CircularProgressIndicator(),
            if (message.isNotEmpty)
              Text(message, style: const TextStyle(color: Colors.red)),
            if (city.isNotEmpty)
              Card(
                elevation: 4,
                margin: const EdgeInsets.only(top: 16),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Pincode: ${_controller.text}",
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text("City: $city"),
                      Text("District: $district"),
                      Text("State: $state"),
                      const SizedBox(height: 8),
                      const Text("Nearby Post Offices:",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      ...postOffices.map((po) => Text("• $po")),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
